<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminTheme\\app\\Providers\\AdminThemeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminTheme\\app\\Providers\\AdminThemeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);