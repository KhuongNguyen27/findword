<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Job\\app\\Providers\\JobServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Job\\app\\Providers\\JobServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);