<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Auth\\app\\Providers\\AuthServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Auth\\app\\Providers\\AuthServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);