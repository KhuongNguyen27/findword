<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminHome\\app\\Providers\\AdminHomeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminHome\\app\\Providers\\AdminHomeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);