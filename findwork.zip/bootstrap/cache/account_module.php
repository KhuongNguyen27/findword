<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Account\\app\\Providers\\AccountServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Account\\app\\Providers\\AccountServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);