<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Employee\\app\\Providers\\EmployeeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Employee\\app\\Providers\\EmployeeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);