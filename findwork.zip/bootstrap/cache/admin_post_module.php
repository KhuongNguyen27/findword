<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminPost\\app\\Providers\\AdminPostServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminPost\\app\\Providers\\AdminPostServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);