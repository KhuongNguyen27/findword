<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Staff\\app\\Providers\\StaffServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Staff\\app\\Providers\\StaffServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);