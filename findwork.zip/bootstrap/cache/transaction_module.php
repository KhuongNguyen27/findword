<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Transaction\\app\\Providers\\TransactionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Transaction\\app\\Providers\\TransactionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);