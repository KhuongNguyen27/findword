<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminTaxonomy\\app\\Providers\\AdminTaxonomyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminTaxonomy\\app\\Providers\\AdminTaxonomyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);