<?php
return [
    'name' => 'AdminUser',
    'type' => 'admin'
];
