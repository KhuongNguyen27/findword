<?php

return [
    'name'              => 'AdminPost',
    'table'             => 'posts',
];
