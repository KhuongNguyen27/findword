@extends('adminpost::edit')
@section('custom-fields-left')
@endsection

@section('custom-fields-right')
@endsection