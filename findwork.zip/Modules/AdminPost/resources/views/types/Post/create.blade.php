@extends('adminpost::create')
@section('custom-fields-left')
@endsection

@section('custom-fields-right')
@endsection