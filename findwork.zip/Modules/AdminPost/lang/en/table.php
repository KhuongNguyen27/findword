<?php
return [
    'name'          => 'Name',
    'description'   => 'Description',
    'start_day'         => 'Started',
    'end_day'         => 'End Day',
    'start_hour'         => 'Start Hour',
    'end_hour'         => 'End Hour',
    'number_day'         => 'Number Day',
    'job_package'         => 'Job Package',
    'image'         => 'Image',
    'status'        => 'Status',
    'created_at'    => 'Created',
    'action'        => 'Action',
];