<?php
return [
    'title_index' => 'All Posts',
    'title_create' => 'Create Post',
    'title_edit' => 'Edit Post',
    'title_show' => 'View Post',
];