<?php
return [
    'name'         => 'Name',
    'description'   => 'Description',
    'image'         => 'Image',
    'status'         => 'Status',
    'discard'       => 'Discard',
    'save_draft'    => 'Save draft',
    'publish'       => 'Publish',
];