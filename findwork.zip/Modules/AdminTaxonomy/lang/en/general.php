<?php
return [
    'title_index' => 'All Taxonomies',
    'title_create' => 'Create Taxonomy',
    'title_edit' => 'Edit Taxonomy',
    'title_show' => 'View Taxonomy',
];