<?php
return [
    'name'          => 'Name',
    'description'   => 'Description',
    'image'         => 'Image',
    'status'        => 'Status',
    'created_at'    => 'Created',
    'action'        => 'Action',
];