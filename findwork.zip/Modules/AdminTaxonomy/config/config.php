<?php

return [
    'name' => 'AdminTaxonomy',
];
