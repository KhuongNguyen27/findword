<?php
return
[
    'dashboard'=>'Trang chủ',

];