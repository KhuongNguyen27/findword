<?php
return
[
    'dashboard'=>'Dashboard',
];
