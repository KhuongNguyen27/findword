<?php

return [
    'name' => 'AdminTheme',
];
