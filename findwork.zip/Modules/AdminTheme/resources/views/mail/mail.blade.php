<div>
    <h3>Hi, {{ $data['name'] }}</h3>
    <b>Your email: {{ $data['email'] }}<br></b>
</div>