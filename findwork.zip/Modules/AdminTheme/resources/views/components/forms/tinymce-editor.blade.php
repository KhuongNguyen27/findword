<textarea>
    Welcome to TinyMCE!
</textarea>