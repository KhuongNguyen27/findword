@error($field)
    <div class="text-danger">{{ $message }}</div>
@enderror