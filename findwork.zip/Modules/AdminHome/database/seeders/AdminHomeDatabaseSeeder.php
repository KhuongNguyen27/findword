<?php

namespace Modules\AdminHome\database\seeders;

use Illuminate\Database\Seeder;

class AdminHomeDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
