@extends('cvs::admin.create')

@section('custom-fields-left')
@include('cvs::admin.includes.form-left')
@endsection

@section('custom-fields-right')
@include('cvs::admin.includes.form-right')
@endsection