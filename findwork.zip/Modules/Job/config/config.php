<?php

return [
    'name' => 'Job',
];
