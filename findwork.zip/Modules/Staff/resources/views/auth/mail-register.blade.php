<div>
    <h3>Xin chào,</h3>
    <p>Findwork vừa có thành viên mới!</p>
    <p>ID: {{ $data['id'] }}</p>
    <p>Tên : {{ $data['name'] }}</p>
    <p>Email: {{ $data['email'] }}</p>
    <p>Loại tài khoản: {{ $data['type'] }}</p>
    <p><br>Nếu bạn không thực hiện bất kỳ hành động nào,<br>vui lòng liên hệ với quản trị viên qua email:<a
            href="gmail.com">
            nguyenhuukhuong27102000@gmail.com</a></p>
</div>