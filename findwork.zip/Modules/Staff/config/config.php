<?php

return [
    'name' => 'Staff',
];
