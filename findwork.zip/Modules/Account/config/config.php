<?php

return [
    'name' => 'Account',
];
