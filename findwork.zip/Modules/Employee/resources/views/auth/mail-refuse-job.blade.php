<div>
    <h3>Xin chào,</h3>
    <span>Cv ứng tuyển công việc {{ $data['job'] }} của bạn đã không đáp ứng yêu cầu!</span>
    <p>Hãy thử lại công việc khác nhé</p>
</div>