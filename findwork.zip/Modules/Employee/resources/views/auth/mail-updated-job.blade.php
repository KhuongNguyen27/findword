<div>
    <h3>Xin chào,</h3>
    <p>Hãy chuẩn bị cho buổi phỏng vấn nhé !</p>
    <p>Người nộp: {{ $data['name'] }}</p>
    <p>Email: {{ $data['email'] }}</p>
    <p>Công việc ứng tuyển : {{ $data['job'] }}</p>
    Hãy chuẩn bị cho buổi phỏng vấn nhé !
</div>