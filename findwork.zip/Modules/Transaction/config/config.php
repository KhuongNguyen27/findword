<?php

return [
    'name' => 'Transaction',
];
