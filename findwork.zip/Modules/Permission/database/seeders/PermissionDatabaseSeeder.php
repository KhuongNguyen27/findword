<?php

namespace Modules\Permission\database\seeders;

use Illuminate\Database\Seeder;

class PermissionDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call([GroupSeeder::class]);
        $this->call([RoleSeeder::class]);
        $this->call([GroupRoleSeeder::class]);
    }
}