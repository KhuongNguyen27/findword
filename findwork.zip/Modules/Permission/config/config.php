<?php

return [
    'name' => 'Permission',
];
